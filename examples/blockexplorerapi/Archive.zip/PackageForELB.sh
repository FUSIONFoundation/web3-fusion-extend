zip -r Archive.zip *.* .ebextensions bin dbapi public routes views -x *.git* -x node_modules -x package-lock.json
